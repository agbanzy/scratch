<?php
if (isset($_POST['submit'])){
    include_once 'dbh.inc.php';
    $title = mysqli_real_escape_string($conn, $_POSt['title']);
    $last = mysqli_real_escape_string($conn, $_POSt['last']);
    $first = mysqli_real_escape_string($conn, $_POSt['first']);
    $designation = mysqli_real_escape_string($conn, $_POSt['designation']);
    $email = mysqli_real_escape_string($conn, $_POSt['email']);
    $mobile = mysqli_real_escape_string($conn, $_POSt['mobile']);
    $pword = mysqli_real_escape_string($conn, $_POSt['uname']);
    $uname = mysqli_real_escape_string($conn, $_POSt['pword']);
    $intercom = mysqli_real_escape_string($conn, $_POSt['intercom']);
    //error handlers
    if (empty($first)||empty($last)||empty($title)||empty($designation)||empty($email)||empty($designation)||empty($pword)){
        header("Locatio:../signup.html?");
        exit;
    }
    else{
//check if input characters are valid
        if (!preg_match("/^[a-zA-Z]*$/",$first,$last) ){
            header("Locatio:../signup.html");
            exit();
        else {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
                header("Locatio:../signup.html");
            }
            else {
                $sql = "SELECT * FROM staffs where user_uname='$uname'";
                $result = mysqli_query($conn, $sql);
                $resultcheck = mysqli_num_rows($result);
                if ($resultcheck > 0){
                    header("Locatio:../signup.html?username taken");
                    exit();
                    //password hashing 
                    $hashpword = password_hash($pword, PASSWORD_BCRYPT);
                    //insert to db
                    $sql = "INSERT INTO staffs (user_designation, user_email, user_first, user_intercom, user_last, user_mobile, user_pword, user_Title, user_uname) values ('$designation', '$email', '$first', '$intercom', '$last', '$mobile', '$hashpword', '$title', '$uname');";
                    mysqli_query ($conn, $sql);
                    echo ("SIGN UP SUCCESSFUL");
                }

                # code...
            }
        }
        }
    }
    {
        header("Locatio:../signup.html");
        exit();  
      }
